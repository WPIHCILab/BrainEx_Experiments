def plot_cluster():
    pass