from brainex import GenexEngine


class BrainexEngine(GenexEngine):
    def __init__(self, **kwargs):
        GenexEngine.__init__(self, **kwargs)